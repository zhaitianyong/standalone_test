segName='   A'
seq="""
ALA THR LEU VAL GLY PRO HIS GLY PRO LEU 
ALA SER GLY GLN LEU ALA ALA PHE HIS ILE 
ALA ALA PRO LEU PRO VAL THR ALA THR ARG 
TRP ASP PHE GLY ASP GLY SER ALA GLU VAL 
ASP ALA ALA GLY PRO ALA ALA SER HIS ARG 
TYR VAL LEU PRO GLY ARG TYR HIS VAL THR 
ALA VAL LEU ALA LEU GLY ALA GLY SER ALA 
LEU LEU GLY THR ASP VAL GLN VAL GLU ALA 
"""
patch_list=[]
seqType='prot'
seqSplit = seq.split()
#print "finished reading ["+`len(seqSplit)`+"] residue(s) for a ["+seqType+"] type segi: ["+segName+"]"
