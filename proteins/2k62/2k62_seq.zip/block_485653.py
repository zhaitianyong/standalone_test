segName='   B'
seq="""
YB
"""
patch_list=[]
seqType='NON-POLYMER'
seqSplit = seq.split()
#print "finished reading ["+`len(seqSplit)`+"] residue(s) for a ["+seqType+"] type segi: ["+segName+"]"
